import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Timer;

/*
 2. You will need to implement a MyClock class that aggregates both ClockFace 
and 3 instances of ClockHand (one each for minute, hour and second. Make sure 
you use appropriate color and thickness for the three hands). Think about what 
you can save in ClockHand to achieve this. 
 */

public class MyClock {
	// Variables
		private int clockRadius;
		private Timer globalTimer; 
		private ClockFace clockFace;
		private ClockHand secondHand;
		private ClockHand minuteHand;
		private ClockHand hourHand;
		
		// Constructor
		public MyClock(int radius) {
			this.clockRadius = radius;
			clockFace = new ClockFace(0, 0, clockRadius);
			
			// Timer to be referenced by all ClockHands
			// Triggers every 1000 milliseconds
			// Shifts the hands and repaints the ClockFace
			globalTimer = new Timer(1000, new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent arg0) {
					secondHand.translate();
					minuteHand.translate();
					hourHand.translate();
					clockFace.repaint();
				}
			});
			globalTimer.start();
			
			// Create and Add ClockHands
			secondHand = new ClockHand(HandType.CLOCK_SECOND, clockRadius, globalTimer, clockFace);
			clockFace.handList.add(secondHand);
			minuteHand = new ClockHand(HandType.CLOCK_MINUTE, clockRadius, globalTimer, clockFace);
			clockFace.handList.add(minuteHand);
			hourHand = new ClockHand(HandType.CLOCK_HOUR, clockRadius, globalTimer, clockFace);
			clockFace.handList.add(hourHand);
		}
		
		// Returns ClockFace for JFrame
		public ClockFace getFace() {
			return clockFace;
		}
		
		// TODO: May need a stop() method to pause the timer when swapping to the Stopwatch
		public void stop() {
			
		}
		// TODO: May need a start() method to start timer when swapping back from the Stopwatch
		public void start() {
			
		}
		
}
